<?php
session_start();
$uri = $_SERVER["REQUEST_URI"];
$uriArray = explode('/', $uri);
$page_url1 = $uriArray[1];
$page_url2 = $uriArray[2];
//$page_url3 = $uriArray[3];
$str = $page_url2;
$strs = ltrim($page_url1, '?');

//$_SESSION['id'] = $ses;

echo '<script type="text/javascript">
    alert("'+$strs+'");
</script>';


// if(isset($ses)){
	// echo '<script type="text/javascript">
    // window.open("main/");
// </script>';
// }


?>