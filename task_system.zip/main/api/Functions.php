<?php
require_once 'DBOperations.php';
class Functions{
private $db;
public function __construct() {
      $this -> db = new DBOperations();
}

public function registerUser($name, $email, $password) {
	$db = $this -> db;
	if (!empty($name) && !empty($email) && !empty($password)) {
  		if ($db -> checkUserExist($email)) {
  			$response["result"] = "failure";
  			$response["message"] = "User Already Registered !";
  			return json_encode($response);
  		} else {
  			$result = $db -> insertData($name, $email, $password);
  			if ($result) {
				  $response["result"] = "success";
  				$response["message"] = "User Registered Successfully !";
  				return json_encode($response);
  			} else {
  				$response["result"] = "failure";
  				$response["message"] = "Registration Failure";
  				return json_encode($response);
  			}
  		}					
  	} else {
  		return $this -> getMsgParamNotEmpty();
  	}
}

public function addUser($fname, $gender, $department, $userGroup, $role, $userID, $email, $password){
  $db = $this -> db;
  if (!empty($fname) && !empty($gender) && !empty($department) && !empty($role) && 
  !empty($userID) &&  !empty($email) && !empty($password)){
    if ($db -> checkUserExist($email)) {
      $response["result"] = "failure";
      $response["message"] = "User Already Registered !";
      return json_encode($response);
    } else {
      $result = $db -> addUser($fname, $gender, $department, $userGroup, $role, $userID, $email, $password);
      if ($result) {
        $response["result"] = "success";
        $response["message"] = "User Registered Successfully !";
        return json_encode($response);
      } else {
        $response["result"] = "failure";
        $response["message"] = "Registration Failed";
        return json_encode($response);
      }
    }	
  }else {
  		return $this -> getMsgParamNotEmpty();
  	}
}

public function add_department($userID, $departmentName, $description){
  $db = $this -> db;
  if(!empty($userID) && !empty($departmentName) && !empty($description)){
    if ($db -> checkDepartmentExist($departmentName)) {
      $response["result"] = "failed";
      $response["message"] = "Department Already Registered !";
      return json_encode($response);
    }else{
      $result = $db -> insertDepartment($userID, $departmentName, $description);
      if ($result) {
        $response["result"] = "success";
        $response["message"] = "Department Added Successfully !";
        return json_encode($response);
      } else {
        $response["result"] = "failure";
        $response["message"] = "Failed !!";
        return json_encode($response);
      }
    }
  }
  else {
    return $this -> getMsgParamNotEmpty();
  }
}

public function loadDepartments($operation){
  $db = $this -> db;
  if(!empty($operation)){
    $result = $db -> loadDepartments($operation);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Departments loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Stats Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function load_taskAssignees($operation){
  $db = $this -> db;
  if(!empty($operation)){
    $result = $db -> load_taskAssignees($operation);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task Assignees loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Load Task Assignees Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function load_taskAssignees2($operation){
  $db = $this -> db;
  if(!empty($operation)){
    $result = $db -> load_taskAssignees2($operation);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task Assignees loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Load Task Assignees Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function load_mention($userID){
  $db = $this -> db;
  if(!empty($userID)){
    $result = $db -> load_mention($userID);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task Mention loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Load Task Mention Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function load_tasksList($operation, $userID){
  $db = $this -> db;
  if(!empty($operation) && !empty($userID)){
    $result = $db -> load_tasksList($operation, $userID);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task List loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Load Task List Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function load_tasksList_list($operation, $userID){
  $db = $this -> db;
  if(!empty($operation) && !empty($userID)){
    $result = $db -> load_tasksList_list($operation, $userID);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task List2 loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Load Task List2 Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function load_tasksList_list_new($operation, $userID){
  $db = $this -> db;
  if(!empty($operation) && !empty($userID)){
    $result = $db -> load_tasksList_list_new($operation, $userID);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task List2 loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Load Task List2 Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function loadtaskUpdate_comments($taskID, $userID){
  $db = $this -> db;
  if(!empty($taskID) && !empty($userID)){
    $result = $db -> loadtaskUpdate_comments($taskID, $userID);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task progress Comments successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Load Progress Comments Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function update_viewTask($taskID, $userID){
  $db = $this -> db;
  if(!empty($taskID) && !empty($userID)){
    $result = $db -> update_viewTask($taskID, $userID);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task Progress Started successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Task Progress Start Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}


public function taskUpdate_comments($userID, $taskID, $assignedTo, $progressComments){
  $db = $this -> db;
  if(!empty($userID) && !empty($taskID) && !empty($assignedTo) && !empty($progressComments)){
    $result = $db -> taskUpdate_comments($userID, $taskID, $assignedTo, $progressComments);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task Progress Comments Updated successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Task Progress Comments Updated Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function add_userGroup($userID, $groupName, $description, $department){
  $db = $this -> db;
  if(!empty($userID) && !empty($groupName) && !empty($description) && !empty($department)){
    if ($db -> checkGroupNameExist($groupName, $department)) {
      $response["result"] = "failed";
      $response["message"] = "User-Group Already Registered !";
      return json_encode($response);
    }else{
      $result = $db -> insertUserGroup($userID, $groupName, $description, $department);
      if ($result) {
        $response["result"] = "success";
        $response["message"] = "User-Group Added Successfully !";
        return json_encode($response);
      } else {
        $response["result"] = "failure";
        $response["message"] = "Failed !!";
        return json_encode($response);
      }
    }
  }
  else {
    return $this -> getMsgParamNotEmpty();
  }
}

public function load_addUser_userGroup($department){
  $db = $this -> db;
  if(!empty($department)){
    $result = $db -> load_addUser_userGroup($department);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "AddUser UserGroups loaded successfully!";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "AddUser UserGroups Failed. Contact Administrator";
        return json_encode($response);
      }
  }else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function add_task($userID, $taskName, $dueDate, $taskCategory, $priority, 
$assignTo, $taskType, $description, $mention){
  $db = $this -> db;
  if(!empty($userID) && !empty($taskName) && !empty($dueDate) && !empty($taskCategory) && !empty($priority)
   && !empty($assignTo) && !empty($taskType) && !empty($description)){
    $result = $db -> add_task($userID, $taskName, $dueDate, $taskCategory, $priority, 
    $assignTo, $taskType, $description ,$mention);
    if ($result) {
      $response["result"] = "success";
      $response["message"] = "Task  Successfully! created";
      $response["user"] = $result;
        return json_encode($response);
      } else {
        $response["result"] = "failed";
        $response["message"] = "Add Task Failed. Contact Administrator";
        return json_encode($response);
      }
   } else{
    return $this -> getMsgParamNotEmpty();
  }
}

public function get_stats($code){
	$db = $this -> db;
	if (!empty($code)) {
  			$result = $db -> getRegStats($code);
  			if ($result) {
				$response["result"] = "success";
  			$response["message"] = "Levy Amount!";
				$response["user"] = $result;
  				return json_encode($response);
  			} else {
  				$response["result"] = "failure";
  				$response["message"] = "Stats Failed. Contact Administrator";
  				return json_encode($response);
  			}
	}else{
		return $this -> getMsgMandatoryLevy();
	}
}

public function loginUser($email, $password) {
  $db = $this -> db;
  if (!empty($email) && !empty($password)) {
    if ($db -> checkUserExist($email)) {
       $result =  $db -> checkLogin($email, $password);
       if(!$result) {
        $response["result"] = "failure";
        $response["message"] = "Invaild Login Credentials";
        return json_encode($response);
       } else {
        $response["result"] = "success";
        $response["message"] = "Login Successful";
        $response["user"] = $result;
        return json_encode($response);
       }
    } else {
      $response["result"] = "failure";
      $response["message"] = "Invaild Login Credentials";
      return json_encode($response);
    }
  } else {
      return $this -> getMsgParamNotEmpty();
    }
}


public function changePassword($email, $old_password, $new_password) {
  $db = $this -> db;
  if (!empty($email) && !empty($old_password) && !empty($new_password)) {
    if(!$db -> checkLogin($email, $old_password)){
      $response["result"] = "failure";
      $response["message"] = 'Invalid Old Password';
      return json_encode($response);
    } else {
    $result = $db -> changePassword($email, $new_password);
      if($result) {
        $response["result"] = "success";
        $response["message"] = "Password Changed Successfully";
        return json_encode($response);
      } else {
        $response["result"] = "failure";
        $response["message"] = 'Error Updating Password';
        return json_encode($response);
      }
    } 
  } else {
      return $this -> getMsgParamNotEmpty();
  }
}

public function isEmailValid($email){
  return filter_var($email, FILTER_VALIDATE_EMAIL);
}

public function getMsgParamNotEmpty(){
  $response["result"] = "failure";
  $response["message"] = "Parameters should not be empty !";
  return json_encode($response);
}

public function getMsgInvalidParam(){
  $response["result"] = "failure";
  $response["message"] = "Invalid Parameters";
  return json_encode($response);
}

public function getMsgInvalidParam1(){
  $response["result"] = "failure";
  $response["message"] = "Not a POST";
  return json_encode($response);
}

public function getMsgInvalidEmail(){
  $response["result"] = "failure";
  $response["message"] = "Invalid Email";
  return json_encode($response);

}

}
