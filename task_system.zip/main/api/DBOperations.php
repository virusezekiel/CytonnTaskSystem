<?php
session_start();
class DBOperations{
	 private $host = '127.0.0.1';
	 private $user = 'root';
	 private $db = 'task_system';
	 private $pass = '0123';
	 private $conn;
public function __construct() {
	$this -> conn = new PDO("mysql:host=".$this -> host.";dbname=".$this -> db, $this -> user, $this -> pass);
}
 public function insertData($name,$email,$password){
 	$unique_id = uniqid('', true);
    $hash = $this->getHash($password);
    $encrypted_password = $hash["encrypted"];
	$salt = $hash["salt"];
 	$sql = 'INSERT INTO users SET unique_id =:unique_id,name =:name,
    email =:email,encrypted_password =:encrypted_password,salt =:salt,created_at = NOW()';
 	$query = $this ->conn ->prepare($sql);
 	$query->execute(array('unique_id' => $unique_id, ':name' => $name, ':email' => $email,
     ':encrypted_password' => $encrypted_password, ':salt' => $salt));
    if ($query) {
        return true;
    } else {
        return false;
    }
 }

 public function addUser($fname, $gender, $department, $userGroup, $role, $userID, $email, $password){
    $unique_id = uniqid('', true);
    $hash = $this->getHash($password);
    $encrypted_password = $hash["encrypted"];
    $salt = $hash["salt"];
    $sql = 'INSERT INTO users SET unique_id =:unique_id,name =:fname,fname = :fname,
    gender =:gender, department =:department, userGroup =:userGroup, role =:role, userID =:userID,
    email =:email,encrypted_password =:encrypted_password,salt =:salt,created_at = NOW()';
 	$query = $this ->conn ->prepare($sql);
     $query->execute(array('unique_id' => $unique_id, ':name' => $fname, 
     ':fname' => $fname, ':gender' => $gender, ':department' => $department,
     ':userGroup' => $userGroup, ':role' => $role, ':userID' => $userID,
     ':email' => $email, ':encrypted_password' => $encrypted_password, ':salt' => $salt));
    if ($query) {
        return true;
    } else {
        return false;
    }
 }

 public function insertDepartment($userID, $departmentName, $description){
    $sql = 'INSERT INTO department SET registered_by =:userID,departmentName =:departmentName,
    departdescription =:description,created_at = NOW()';
 	$query = $this ->conn ->prepare($sql);
 	$query->execute(array('userID' => $userID, ':departmentName' => $departmentName, ':description' => $description));
    if ($query) {
        return true;
    } else {
        return false;
    }
 }

 public function loadDepartments($operation){
    $sql = 'SELECT * FROM `department` where status =:operation';
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':operation' => $operation));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function load_taskAssignees($operation){
    $sql = 'SELECT departmentName AS label, unique_id AS value, Fname AS name,
     department AS optgroup FROM users us 
     INNER JOIN department dt ON us.department = dt.depart_id WHERE us.status =:operation';
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':operation' => $operation));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function load_taskAssignees2($operation){
    $sql = 'SELECT department AS value, departmentName AS label FROM users us 
     INNER JOIN department dt ON us.department = dt.depart_id WHERE us.status =:operation';
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':operation' => $operation));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function load_mention($userID){
    $sql = 'SELECT unique_id AS id, fname AS title , department FROM users cs 
    INNER JOIN department dt ON dt.depart_id = cs.department 
    WHERE department = (SELECT department FROM users WHERE unique_id =:operation AND role =:role) ' ;
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':operation' => $userID, ':role' => '1'));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function load_tasksList($operation, $userID){
    $sql = 'SELECT tasks_id AS id, tasks_id, assignTo, taskName AS name, taskName AS title, taskGroup AS tgroup ,
     description, priority AS status, fname AS assignee 
    FROM tasks sk INNER JOIN users us ON sk.registered_by = us.unique_id 
    WHERE us.status = :operation AND assignTo =:userID' ;
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':operation' => $operation, ':userID' => $userID));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function load_tasksList_list_new($operation, $userID){
    $sql = 'SELECT tasks_id AS id, tasks_id, assignTo, taskName AS name, taskName AS title, taskGroup AS tgroup ,
     description, priority AS status, fname AS assignee 
    FROM tasks sk INNER JOIN users us ON sk.registered_by = us.unique_id 
    WHERE us.status = :operation AND assignTo =:userID AND taskStatus =:taskState' ;
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':operation' => $operation, ':userID' => $userID, ':taskState' => 'New'));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }
 
 public function load_tasksList_list($operation, $userID){
    $sql = 'SELECT tasks_id AS item_id, us.role,assignTo, tasks_id, taskName AS short_name, taskName AS title, 
    taskGroup AS tgroup, description, priority, sk.taskStatus AS status, fname AS assignee,
    us.created_at AS date_created, dueDate as date_updated, uploadFile, progress  
    FROM tasks sk INNER JOIN users us ON sk.registered_by = us.unique_id 
    WHERE  assignTo =:userID' ;
		$query = $this ->conn ->prepare($sql);
		$query -> execute(array( ':userID' => $userID));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function loadtaskUpdate_comments($taskID, $userID){
    $sql = 'SELECT fname, tp.assignee, tp.taskID, progressComments, tp.created_at FROM taskProgress tp
    INNER JOIN users us on tp.assignee = us.unique_id 
    WHERE tp.assignee =:userID AND tp.taskID =:taskID ';
		$query = $this ->conn ->prepare($sql);
		$query -> execute(array( ':userID' => $userID, ':taskID' => $taskID));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function update_viewTask($taskID, $userID){
    $sql = 'UPDATE tasks SET taskStatus = :taskStatus, taskGroup = :taskGroup 
            WHERE tasks_id = :taskID AND assignTo = :userID' ;
		$query = $this ->conn ->prepare($sql);
        $query -> execute(array(':taskStatus' => 'open', ':taskGroup' => 'inProgress', 
        ':taskID' => $taskID, ':userID' => $userID));
		if ($query) {
            return true;
        } else {
            return false;
        }
 }

 public function taskUpdate_comments($userID, $taskID, $assignedTo, $progressComments){
    $sql = 'INSERT INTO taskProgress SET assignee =:assignedTo, progressComments =:progressCommentss,
            registered_by =:userID, taskID =:taskID, created_at = NOW()' ;
		$query = $this ->conn ->prepare($sql);
        $query -> execute(array(':assignedTo' => $assignedTo, ':progressCommentss' => $progressComments, 
        'taskID' =>$taskID ,':userID' => $userID));
		if ($query) {
            return true;
        } else {
            return false;
        }
 }

 public function insertUserGroup($userID, $groupName, $description, $department){
    $sql = 'INSERT INTO usergroup SET registered_by =:userID,groupName =:groupName,
    groupDescription =:description,department = :department ,created_at = NOW()';
 	$query = $this ->conn ->prepare($sql);
     $query->execute(array('userID' => $userID, ':groupName' => $groupName, ':description' => $description
                            , ':department' => $department));
    if ($query) {
        return true;
    } else {
        return false;
    }
 }

 public function load_addUser_userGroup($department){
    $sql = 'SELECT * FROM `usergroup` where department =:department';
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':department' => $department));
		$data = $query -> fetchALL(PDO::FETCH_ASSOC);
		if($query){
			return $data;
		} else {
			return false;
		}
 }

 public function add_task($userID, $taskName, $dueDate, $taskCategory, $priority, 
 $assignTo, $taskType, $description,$mention){
     $mentions = implode(",", $mention);
    $sql = 'INSERT INTO tasks SET taskName =:taskName,dueDate =:dueDate,
    taskCategory =:taskCategory,priority = :priority, assignTo = :assignTo, taskType = :taskType, 
    description = :description, mention = :mention, registered_by =:userID, created_at = NOW()';
 	$query = $this ->conn ->prepare($sql);
    $query->execute(array('taskName' => $taskName, ':dueDate' => $dueDate, ':taskCategory' => $taskCategory
                    , ':priority' => $priority, ':assignTo' =>$assignTo, ':taskType' => $taskType,
                    ':description' => $description,':mention' => $mentions, ':userID' => $userID));

    $query2 = 'SELECT tasks_id from tasks where registered_by = :userID order by created_at desc limit 1';
    $query_res = $this -> conn -> prepare($query2);
    $query_res -> execute(array(':userID' => $userID));
    $data = $query_res -> fetchObject();
    if ($query_res) {
        $user['tasks_id'] = $data -> tasks_id;
        return $user;
    } else {
        return false;
    }
 }
 
 public function getRegStats($code){
		$sql = 'SELECT fname, role FROM users where unique_id = :code';
		$query = $this -> conn -> prepare($sql);
		$query -> execute(array(':code' => $code));
		$data = $query -> fetchObject();
		if($query){
			$user['fname'] = $data -> fname;
			$user['role'] = $data -> role;
			return $user;
		} else {
			return false;
		}
	 }

 public function checkLogin($email, $password) {
    $sql = 'SELECT * FROM users WHERE email = :email';
    $query = $this -> conn -> prepare($sql);
    $query -> execute(array(':email' => $email));
    $data = $query -> fetchObject();
    $salt = $data -> salt;
    $db_encrypted_password = $data -> encrypted_password;
    if ($this -> verifyHash($password.$salt,$db_encrypted_password) ) {
        $user["name"] = $data -> name;
        $user["email"] = $data -> email;
        $user["unique_id"] = $data -> unique_id;
        return $user;
    } else {
        return false;
    }
 }


 public function changePassword($email, $password){
    $hash = $this -> getHash($password);
    $encrypted_password = $hash["encrypted"];
    $salt = $hash["salt"];
    $sql = 'UPDATE users SET encrypted_password = :encrypted_password, salt = :salt WHERE email = :email';
    $query = $this -> conn -> prepare($sql);
    $query -> execute(array(':email' => $email, ':encrypted_password' => $encrypted_password, ':salt' => $salt));
    if ($query) {
        return true;
    } else {
        return false;
    }
 }

 public function checkDepartmentExist($departmentName){
    $sql = 'SELECT COUNT(*) from department WHERE departmentName =:departmentName';
    $query = $this -> conn -> prepare($sql);
    $query -> execute(array('departmentName' => $departmentName));
    if($query){
        $row_count = $query -> fetchColumn();
        if ($row_count == 0){
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
 }

 public function checkGroupNameExist($groupName, $department){
    $sql = 'SELECT COUNT(*) from usergroup WHERE groupName =:groupName and department = :department';
    $query = $this -> conn -> prepare($sql);
    $query -> execute(array('groupName' => $groupName, 'department' => $department));
    if($query){
        $row_count = $query -> fetchColumn();
        if ($row_count == 0){
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
 }

 public function checkUserExist($email){
    $sql = 'SELECT COUNT(*) from users WHERE email =:email';
    $query = $this -> conn -> prepare($sql);
    $query -> execute(array('email' => $email));
    if($query){
        $row_count = $query -> fetchColumn();
        if ($row_count == 0){
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
 }

 public function getHash($password) {
     $salt = sha1(rand());
     $salt = substr($salt, 0, 10);
     $encrypted = password_hash($password.$salt, PASSWORD_DEFAULT);
     $hash = array("salt" => $salt, "encrypted" => $encrypted);
     return $hash;
}

    public function verifyHash($password, $hash) {
        return password_verify ($password, $hash);
    }
}




