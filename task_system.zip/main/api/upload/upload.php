<?php

    mysql_select_db('task_system',mysql_connect('localhost','root','0123'))or die(mysql_error());

    /* Getting file name */
    $filename = $_FILES['file']['name'];
    if(!empty($filename) && !empty($_GET['tasksID'])){

            /* Location */
        $location = 'upload/';

        // Upload file
        move_uploaded_file($_FILES['file']['tmp_name'],$location.$filename);

        $users = $_GET['tasksID'];

        $arr = array('name'=>$filename);
        //echo json_encode($arr);

        $name = $location.$filename;

        $qwuery = mysql_query("UPDATE tasks set uploadFile = '$name' WHERE tasks_id = '$users'") or die (mysql_error());
        if($qwuery){
            echo json_encode($qwuery + "....." + $users + "Success");
            echo "Success";
        }
    }
    else {
        echo json_encode("Error. No file Found.Success");
    }
 
?>


