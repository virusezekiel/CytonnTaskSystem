<?php
//include ('dbcon.php');
session_start();
include('session.php');

session_destroy();
header('location:../');
?>