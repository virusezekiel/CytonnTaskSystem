<?php
header('Content-type: application/json');
require_once 'Functions.php';

$fun = new Functions();


if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
  $data = json_decode(file_get_contents("php://input"));
  //json_decode($_POST["myData"]);
  
  

  if(isset($data -> operation)){

  	$operation = $data -> operation;

  	if(!empty($operation)){

  		if($operation == 'register'){
  			if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> name) 
  				&& isset($data -> user -> email) && isset($data -> user -> password)){
  				$user = $data -> user;
  				$name = $user -> name;
  				$email = $user -> email;
  				$password = $user -> password;
          if ($fun -> isEmailValid($email)) {
            echo $fun -> registerUser($name, $email, $password);
          } else {
            echo $fun -> getMsgInvalidEmail();
          }
  			} else {
  				echo $fun -> getMsgInvalidParam();
  			}
      }

      else if($operation == "add_user"){
        if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> fname)
          && isset($data -> user -> gender) && isset($data -> user -> department)
          && isset($data -> user -> userGroup) && isset($data -> user -> role) && isset($data -> user -> userID)
  				&& isset($data -> user -> email) && isset($data -> user -> password)){
            $user = $data -> user;
  				  $fname = $user -> fname;
  				  $gender = $user -> gender;
  				  $department = $user -> department;
  				  $userGroup = $user -> userGroup;
  				  $role = $user -> role;
  				  $userID = $user -> userID;
  				  $email = $user -> email;
  				  $password = $user -> password;
            if ($fun -> isEmailValid($email)) {
              echo $fun -> addUser($fname, $gender, $department, $userGroup, $role, $userID, $email, $password);
            } else {
              echo $fun -> getMsgInvalidEmail();
            }
          }else{
            echo $fun -> getMsgInvalidParam();
          }
      }

      else if($operation == "add_task"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> taskName) 
        && isset($data -> user -> dueDate) && isset($data -> user -> taskCategory)
        && isset($data -> user -> priority) && isset($data -> user -> assignTo) 
        && isset($data -> user -> taskType) && isset($data -> user -> description)
        && isset($data -> user -> userID) && isset($data -> user -> mentioned) ){
            $user = $data -> user;
  				  $taskName = $user -> taskName;
  				  $dueDate = $user -> dueDate;
  				  $taskCategory = $user -> taskCategory;
  				  $priority = $user -> priority;
  				  $assignTo = $user -> assignTo;
  				  $taskType = $user -> taskType;
  				  $description = $user -> description;
  				  $mention = $user -> mentioned;
  				  // $uploadFile = $user -> uploadFile;
  				  $userID = $user -> userID;
          echo $fun -> add_task($userID, $taskName, $dueDate, $taskCategory, $priority, 
          $assignTo, $taskType, $description, $mention );
        } else {
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == 'add_department'){
        if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> userID) && isset($data -> user -> departmentName) && isset($data -> user -> description)){
          $user = $data -> user;
          $userID = $user -> userID;
          $departmentName = $user -> departmentName;
          $description = $user -> description;
          echo $fun -> add_department($userID, $departmentName, $description);
        }else{ 
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_departments"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> operation)){
          $user = $data -> user;
          $operation = $user -> operation;
          echo $fun -> loadDepartments($operation);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_taskAssignees"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> operation)){
          $user = $data -> user;
          $operation = $user -> operation;
          echo $fun -> load_taskAssignees($operation);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_taskAssignees2"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> operation)){
          $user = $data -> user;
          $operation = $user -> operation;
          echo $fun -> load_taskAssignees2($operation);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_mention"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> userID)){
          $user = $data -> user;
          $userID = $user -> userID;
          echo $fun -> load_mention($userID);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_tasksList"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> operation) 
        && isset($data -> user -> userID)){
          $user = $data -> user;
          $operation = $user -> operation;
          $userID = $user -> userID;
          echo $fun -> load_tasksList($operation, $userID);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_tasksList_list"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> operation) 
        && isset($data -> user -> userID)){
          $user = $data -> user;
          $operation = $user -> operation;
          $userID = $user -> userID;
          echo $fun -> load_tasksList_list($operation, $userID);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_tasksList_list_new"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> operation) 
        && isset($data -> user -> userID)){
          $user = $data -> user;
          $operation = $user -> operation;
          $userID = $user -> userID;
          echo $fun -> load_tasksList_list_new($operation, $userID);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }


      else if($operation == "loadtaskUpdate_comments"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> taskID) 
        && isset($data -> user -> userID)){
          $user = $data -> user;
          $taskID = $user -> taskID;
          $userID = $user -> userID;
          echo $fun -> loadtaskUpdate_comments($taskID, $userID);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == 'add_userGroup'){
        if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> userID) 
        && isset($data -> user -> groupName) && isset($data -> user -> description) 
        && isset($data -> user -> department)){
          $user = $data -> user;
          $userID = $user -> userID;
          $groupName = $user -> groupName;
          $description = $user -> description;
          $department = $user -> department;
          echo $fun -> add_userGroup($userID, $groupName, $description, $department);
        }else{ 
          echo $fun -> getMsgInvalidParam();
        }
      }
      
      else if($operation == 'taskUpdate_comments'){
        if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> userID) 
        && isset($data -> user -> assignedTo) && isset($data -> user -> progressComments)
        && isset($data -> user -> taskID)){
          $user = $data -> user;
          $userID = $user -> userID;
          $taskID = $user -> taskID;
          $assignedTo = $user -> assignedTo;
          $progressComments = $user -> progressComments;
          echo $fun -> taskUpdate_comments($userID, $taskID, $assignedTo, $progressComments);
        }else{ 
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if($operation == "load_addUser_userGroup"){
        if(isset($data -> user) && !empty($data -> user) && isset($data -> user -> department)){
          $user = $data -> user;
          $department = $user -> department;
          echo $fun -> load_addUser_userGroup($department);
        }else{
          echo $fun -> getMsgInvalidParam();
        }
      }

      else if ($operation == 'login') {
        if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> email) && isset($data -> user -> password)){
          $user = $data -> user;
          $email = $user -> email;
          $password = $user -> password;
          echo $fun -> loginUser($email, $password);
        } else {
          echo $fun -> getMsgInvalidParam();
        }
      }

    else if($operation == 'update_viewTask'){
      if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> userID) 
      && isset($data -> user -> taskID)){
				$user = $data -> user;
				$userID = $user -> userID;
				$taskID = $user -> taskID;
				echo $fun -> update_viewTask($taskID, $userID);
			}else{
				//echo "this not fun at all"; 
				echo $fun -> getMsgInvalidParam();
			}
    }  

	  else if($operation == 'get_stats'){
			if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> userID)){
				$user = $data -> user;
				$code = $user -> userID;
				echo $fun -> get_stats($code);
			}else{
				//echo "this not fun at all"; 
				echo $fun -> getMsgInvalidParam();
			}
    }
		
	  else if ($operation == 'chgPass') {

        if(isset($data -> user ) && !empty($data -> user) && isset($data -> user -> email) && isset($data -> user -> old_password) 
          && isset($data -> user -> new_password)){

          $user = $data -> user;
          $email = $user -> email;
          $old_password = $user -> old_password;
          $new_password = $user -> new_password;

          echo $fun -> changePassword($email, $old_password, $new_password);

        } else {

          echo $fun -> getMsgInvalidParam();

        }
      }

  	}else{

  		echo $fun -> getMsgParamNotEmpty();

  	}
  } else {

  		echo $fun -> getMsgInvalidParam1();

  }
} else if ($_SERVER['REQUEST_METHOD'] == 'GET'){


  echo "CYTONN TASK SYSTEM";

}

