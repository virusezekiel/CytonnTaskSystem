var itemDetailID = "";
loadProgressTasksComments = [];
var TaskProgress = "";
var AssginedToTas = "";
var it = $('#taskItemid').val();
console.log(it);
        //Load Task ID
        function startTaskProgress(){
        console.log(itemDetailID);
        var updateViewTask = {};
		updateViewTask.operation = "update_viewTask";
        updateViewTask.user = {};
        updateViewTask.user.taskID = itemDetailID;
        updateViewTask.user.userID = loggedinguy;
		console.log(updateViewTask);
		$.ajax({
			url: "api/index.php/",
			data: JSON.stringify(updateViewTask),
			type: 'POST',
			datatype: 'JSON',
			contentType: "application/json; charset=utf-8",
			success: function (result) {
                console.log(result);
                if(result.message.includes("success")){
                    TaskProgress = "open";
                    //$('#btnstartTaskProgress').hide();
                    $('#link_clickAfterUpdate').click();
                    //alert(result.message);
                }
			}
        });
    }

    //Add Task Progress Comments
    
    function taskProgressUpdate(){
        var comments = $('#taskViewProgressComments').val();
        console.log("Comments " + comments + " Assgined To: " + AssginedToTas);
        var viewTaskProgressUpdate = {};
        viewTaskProgressUpdate.operation = "taskUpdate_comments";
        viewTaskProgressUpdate.user = {};
        viewTaskProgressUpdate.user.userID = loggedinguy;
        viewTaskProgressUpdate.user.assignedTo = AssginedToTas;
        viewTaskProgressUpdate.user.progressComments = comments;
        viewTaskProgressUpdate.user.taskID = itemDetailID;
        console.log(viewTaskProgressUpdate);
		$.ajax({
			url: "api/index.php/",
			data: JSON.stringify(viewTaskProgressUpdate),
			type: 'POST',
			datatype: 'JSON',
			contentType: "application/json; charset=utf-8",
			success: function (result) {
                console.log(result);
                if(result.message.includes("success")){
                    TaskProgress = "open";
                    $('#link_clickAfterUpdate').click();
                    //document.getElementById('link_clickAfterUpdate').click();
                    $('#addTaskCommSuccess').click();
                }else{
                    $('#addTaskCommFail').click();
                }
			}
        });
    }

    


angular
    .module('altairApp')
    .controller('issuesCtrl', [
        '$rootScope',
        '$scope',
        '$stateParams',
        '$http',
        'issues_data',
        'utils',
        'variables',
        function ($rootScope,$scope,$stateParams,$http,issues_data,utils,variables) {

            $rootScope.pageHeadingActive = true;

            $scope.view_task_role = role;
            
            

            $scope.view_task_progress = TaskProgress;

            $scope.$on('$destroy', function() {
                $rootScope.pageHeadingActive = false;
            });

            $scope.project_name = 'Task System';

            $scope.issues = issues_data;
            

            if($scope.issues === undefined){
                $scope.issue_details = [];
                $scope.view_task_id = "";
                $scope.view_task_btn_prog = "";
                $scope.view_task_assignedTo = "";
            }else{
                $scope.issue_details = utils.findByItemId($scope.issues, $stateParams.issueId);
                if (utils.findByItemId($scope.issues, $stateParams.issueId) === null){
                    itemDetailID = "";
                    AssginedToTas = "";
                }else{
                    $scope.view_task_id = utils.findByItemId($scope.issues, $stateParams.issueId).item_id;
                    $scope.view_task_btn_prog = utils.findByItemId($scope.issues, $stateParams.issueId).status;
                    $scope.view_task_assignedTo = utils.findByItemId($scope.issues, $stateParams.issueId).assignTo
                    if($scope.view_task_id === null){
                        itemDetailID = "";
                        AssginedToTas = "";
                    }else{
                        itemDetailID = $scope.view_task_id;
                        $scope.view_task_progress_btn_start = $scope.view_task_btn_prog;
                        $scope.view_task_progress_assignedTo = $scope.view_task_assignedTo;
                        AssginedToTas = $scope.view_task_assignedTo;
                        
                        
                        
                    }
                }
            }
            console.log($scope.view_task_id);
            var loadedTaskProgressUpdate = {};
            loadedTaskProgressUpdate.operation = "loadtaskUpdate_comments";
            loadedTaskProgressUpdate.user = {};
            loadedTaskProgressUpdate.user.userID = loggedinguy;
            loadedTaskProgressUpdate.user.taskID = $scope.view_task_id;
            console.log(loadedTaskProgressUpdate);
            var url = 'api/index.php/';
            var data = JSON.stringify(loadedTaskProgressUpdate);
            $http.post(url, data).then(function(result){
                console.log(result.data);
                $rootScope.taskUpdates = result.data.user;
            });
            
            $rootScope.taskUpdates = loadProgressTasksComments;

            console.log(loadProgressTasksComments);
            

            //$scope.view_task_id = utils.findByItemId($scope.issues, $stateParams.issueId).item_id

           //console.log(utils.findByItemId($scope.issues, $stateParams.issueId).item_id);

            $scope.newTask = {
                name: 'Altair-245',
                assignee: [

                ],
                group: [
                    { name: 'todo', title: 'To Do' },
                    { name: 'inAnalysis', title: 'In Analysis' },
                    { name: 'inProgress', title: 'In Progress' },
                    { name: 'done', title: 'Done' }
                ]
            };

            $scope.newIssue = {
                assignee: {
                    config: {
                        create:false,
                        maxItems: 1,
                        valueField: 'id',
                        labelField: 'title',
                        placeholder: 'Select Assignee...'
                    },
                    options: [
                        { id: 1, title: 'Aleen Grant' },
                        { id: 2, title: 'Tyrese Koss' },
                        { id: 3, title: 'Chasity Green' },
                        { id: 4, title: 'Me' }
                    ]
                }
            };

            $scope.$on('onLastRepeat', function (scope, element, attrs) {

                // issues list tablesorter
                var $ts_issues = $("#ts_issues");
                if($(element).closest($ts_issues).length) {

                    // define pager options
                    var pagerOptions = {
                        // target the pager markup - see the HTML block below
                        container: $(".ts_pager"),
                        // output string - default is '{page}/{totalPages}'; possible variables: {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
                        output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',
                        // if true, the table will remain the same height no matter how many records are displayed. The space is made up by an empty
                        // table row set to a height to compensate; default is false
                        fixedHeight: true,
                        // remove rows from the table to speed up the sort of large tables.
                        // setting this to false, only hides the non-visible rows; needed if you plan to add/remove rows with the pager enabled.
                        removeRows: false,
                        // go to page selector - select dropdown that sets the current page
                        cssGoto: '.ts_gotoPage'
                    };

                    // Initialize tablesorter
                    $ts_issues
                        .tablesorter({
                            theme: 'altair',
                            widthFixed: true,
                            widgets: ['zebra', 'filter']
                        })
                        // initialize the pager plugin
                        .tablesorterPager(pagerOptions)
                        .on('pagerComplete', function (e, filter) {
                            // update selectize value
                            if (typeof selectizeObj !== 'undefined' && selectizeObj.data('selectize')) {
                                selectizePage = selectizeObj[0].selectize;
                                selectizePage.setValue($('select.ts_gotoPage option:selected').index() + 1, false);
                            }

                        });

                    // replace 'goto Page' select
                    function createPageSelectize() {
                        selectizeObj = $('select.ts_gotoPage')
                            .val($("select.ts_gotoPage option:selected").val())
                            .after('<div class="selectize_fix"></div>')
                            .selectize({
                                hideSelected: true,
                                onDropdownOpen: function ($dropdown) {
                                    $dropdown
                                        .hide()
                                        .velocity('slideDown', {
                                            duration: 200,
                                            easing: variables.easing_swiftOut
                                        })
                                },
                                onDropdownClose: function ($dropdown) {
                                    $dropdown
                                        .show()
                                        .velocity('slideUp', {
                                            duration: 200,
                                            easing: variables.easing_swiftOut
                                        });

                                    // hide tooltip
                                    $('.uk-tooltip').hide();
                                }
                            });
                    }

                    createPageSelectize();

                    // replace 'pagesize' select
                    $('.pagesize.ts_selectize')
                        .after('<div class="selectize_fix"></div>')
                        .selectize({
                            hideSelected: true,
                            onDropdownOpen: function ($dropdown) {
                                $dropdown
                                    .hide()
                                    .velocity('slideDown', {
                                        duration: 200,
                                        easing: variables.easing_swiftOut
                                    })
                            },
                            onDropdownClose: function ($dropdown) {
                                $dropdown
                                    .show()
                                    .velocity('slideUp', {
                                        duration: 200,
                                        easing: variables.easing_swiftOut
                                    });

                                // hide tooltip
                                $('.uk-tooltip').hide();

                                if (typeof selectizeObj !== 'undefined' && selectizeObj.data('selectize')) {
                                    selectizePage = selectizeObj[0].selectize;
                                    selectizePage.destroy();
                                    $('.ts_gotoPage').next('.selectize_fix').remove();
                                    setTimeout(function () {
                                        createPageSelectize()
                                    })
                                }

                            }
                        });
                }

            })

        }
    ]);