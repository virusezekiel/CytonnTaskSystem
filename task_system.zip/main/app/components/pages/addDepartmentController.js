
angular
    .module('altairApp')
    .controller('advancedCtrl', [
        '$scope',
        '$rootScope',
        '$timeout',
        '$add_department',
        function ($scope,$rootScope,$timeout,$add_department) {

            $scope.forms_advanced = {
                "input_error": "Something wrong",
                "input_ok": "All ok",
                "ionslider_1": 23,
                "ionslider_2": {
                    "from": 160,
                    "to": 592
                },
                "ionslider_3": 40,
                "ionslider_4": {
                    "from": 20,
                    "to": 80
                },
                selectize_planets: []
            };
			
			var $formValidate = $('#form_add_department');

            // model change
            $timeout(function() {
                $scope.forms_advanced.datepicker = "23.06.2016"
            }, 5000);
			
			$add_department = function(){
				console.log("Clicked");
			};

        // Advanced selects
		
		$scope.submit = function(add_department){
			console.log(add_department);
		};

            
        }
    ]);