var taskAssignees2 = [];
        var loadTaskAssignee2 = {};
		loadTaskAssignee2.operation = "load_taskAssignees2";
        loadTaskAssignee2.user = {};
        loadTaskAssignee2.user.operation = "A";
		console.log(loadTaskAssignee2);
		$.ajax({
			url: "api/index.php/",
			data: JSON.stringify(loadTaskAssignee2),
			type: 'POST',
			datatype: 'JSON',
			contentType: "application/json; charset=utf-8",
			success: function (result) {
                console.log(result.user);
                if(result.user === undefined){
                    taskAssignees2 = [];
                }else{
                    taskAssignees2 = result.user;
                    console.log(taskAssignees2);
                }
			}
        });
angular
    .module('altairApp')
    .controller('advancedCtrl', [
        '$scope',
        '$rootScope',
        '$timeout',
        '$http',
        function ($scope,$rootScope,$timeout,$http) {
            var self = this;
            //Add New Department
			$scope.add_departments = function(add_department){
                 add_department.user = {};
                 add_department.operation = "add_department";
                 add_department.user.departmentName = add_department.departmentName;
                 add_department.user.description = add_department.description;
                 add_department.user.userID = loggedinguy;
                 console.log(JSON.stringify(add_department));
                var url = 'api/index.php/';
                var data = JSON.stringify(add_department);
                $http.post(url, data).then(function(result){/*  */
                    console.log(result.data);
                    if(result.data.message.includes("Success")){
                        add_department.departmentName = "";
                        add_department.description = "";
                        $('#addDepartmentSuccess').click();
                    }else if(result.data.message.includes("Already")){
                        $('#addDepartmentWarn').click();
                    }else{
                        $('#addDepartmentFail').click();
                    }
                });
            };
            //Display Departments
            $scope.departments = [];
            $scope.loadDepartments = function(){
                console.log("Departments to start loading here");
                self.loadDepart = {};
                self.loadDepart.operation = "load_departments";
                self.loadDepart.user = {};
                self.loadDepart.user.operation = "A";
                console.log(self.loadDepart);
                var url = 'api/index.php/';
                var data = JSON.stringify(self.loadDepart);
                $http.post(url, data).then(function(result){
                    console.log(result.data);
                    $scope.departments = result.data.user;
                    console.log($scope.departments);
                });
            }

            //Add new user Group
            $scope.addUsergroup = function(add_userGroup){
                add_userGroup.operation = "add_userGroup";
                add_userGroup.user = {};
                add_userGroup.user.groupName = add_userGroup.groupName;
                add_userGroup.user.department = add_userGroup.department;
                add_userGroup.user.description = add_userGroup.description;
                add_userGroup.user.userID = loggedinguy;
                console.log(add_userGroup);
                var url = 'api/index.php/';
                var data = JSON.stringify(add_userGroup);
                $http.post(url, data).then(function(result){
                    console.log(result.data);
                    if(result.data.message.includes("Success")){
                        add_userGroup.groupName = "";
                        add_userGroup.department = "";
                        add_userGroup.description = "";
                        $('#addUserGroupSuccess').click();
                    }else if(result.data.message.includes("Already")){
                        $('#addUserGroupWarn').click();
                    }else{
                        $('#addUserGroupFail').click();
                    }
                });
            }
            //Load UserGroups Depending on the selected Department
            $scope.addUser_userGroup = [];
            $scope.loadUserGroups = function(id){
                console.log("Selected Department is: " + id);
                self.loadUserGroup = {};
                self.loadUserGroup.operation = "load_addUser_userGroup";
                self.loadUserGroup.user = {};
                self.loadUserGroup.user.department = id;
                console.log(self.loadUserGroup);
                var url = 'api/index.php/';
                var data = JSON.stringify(self.loadUserGroup);
                $http.post(url, data).then(function(result){
                    console.log(result.data);
                    $scope.addUser_userGroup = result.data.user;
                    console.log($scope.addUser_userGroup);
                });
            }

            //Add New System User
            $scope.add_users = function(add_user){
                console.log("Begin Add new user " + add_user);
                add_user.operation = "add_user";
                add_user.user = {};
                add_user.user.fname = add_user.fName;
                add_user.user.gender = add_user.genders;
                add_user.user.department = add_user.department;
                add_user.user.userGroup = add_user.userGroup;
                add_user.user.role = add_user.role;
                add_user.user.email = add_user.email;
                add_user.user.password = add_user.password;
                add_user.user.userID = loggedinguy;
                console.log(add_user);
                var url = 'api/index.php/';
                var data = JSON.stringify(add_user);
                $http.post(url, data).then(function(result){
                    console.log(result.data);
                    if(result.data.message.includes("Success")){
                        add_user.fName = "";
                        add_user.genders = "";
                        add_user.department = "";
                        add_user.userGroup = "";
                        add_user.role = "";
                        add_user.email = "";
                        add_user.password = "";
                        $('#addUserGroupSuccess').click();
                    }else if(result.data.message.includes("Already")){
                        $('#addUserGroupWarn').click();
                    }else{
                        $('#addUserGroupFail').click();
                    }
                });
            }
            

            //Add New Task
            $scope.addTask = function(add_task){
                console.log(add_task);
                var file = $scope.uploadfile;
                var fd = new FormData();
                var files = document.getElementById('file').files[0];
                fd.append('file',files);
                fd.append('user', loggedinguy);
                
                add_task.operation = "add_task";
                add_task.user = {};
                add_task.user.taskName = add_task.taskName;
                add_task.user.dueDate = add_task.dueDate;
                add_task.user.taskCategory = add_task.taskCategory;
                add_task.user.priority = add_task.priority;
                add_task.user.assignTo = add_task.assignTo;
                add_task.user.taskType = add_task.taskType;
                if(add_task.mentioned){
                    add_task.mentioned;
                }else{
                    add_task.mentioned = [];
                }
                add_task.user.mentioned = add_task.mentioned;
                add_task.user.description = add_task.description;
                //add_task.user.uploadFile = fd.append('file',files);
                add_task.user.userID = loggedinguy;
                console.log(add_task);
                $http({
                method: 'post',
                url: 'api/index.php/',
                data: add_task,
                headers: {'Content-Type': undefined},
                }).then(function(result){ 
                    console.log(result);
                    if(result.data.message.includes("Success")){
                        if(result.data.user.tasks_id != ""){
                            console.log(result.data.user.tasks_id);
                            $http({
                                method: 'post',
                                url: 'api/upload/upload.php?tasksID='+result.data.user.tasks_id,
                                data: fd,
                                headers: {'Content-Type': undefined},
                              }).then(function successCallback(response) { 
                                // Store response data
                                console.log( response);
                                if(response.data.includes("Success")){
                                    add_task.taskName = "";
                                    add_task.dueDate = "";
                                    add_task.taskCategory = "";
                                    add_task.priority = "";
                                    add_task.assignTo = "";
                                    add_task.taskType = "";
                                    add_task.mentioned = "";
                                    add_task.description = "";
                                    add_task.fileArray = [];
                                    add_task.fileArray = "";
                                    $('#addTaskSuccess').click();
                                }else{
                                    $('#addTaskFail').click();
                                }
                              });
                        }
                    }else{
                        $('#addTaskFail').click();
                    }
                });
            }

            //Load Users to Tasks
            $scope.taskAssignees = [];
            $scope.loadTaskAssignees = function(){
                console.log("Departments to start loading here");
                self.loadTaskAssignee = {};
                self.loadTaskAssignee.operation = "load_taskAssignees";
                self.loadTaskAssignee.user = {};
                self.loadTaskAssignee.user.operation = "A";
                console.log(self.loadTaskAssignee);
                var url = 'api/index.php/';
                var data = JSON.stringify(self.loadTaskAssignee);
                $http.post(url, data).then(function(result){
                    console.log(result.data);
                    $scope.taskAssignees = result.data.user;
                    console.log($scope.taskAssignees);
                });
            }

            //Load Mention Heads
            $scope.loadMention = function(id){
                console.log(id);
                if(id != ""){
                    self.loadMention = {};
                    self.loadMention.operation = "load_mention";
                    self.loadMention.user = {};
                    self.loadMention.user.userID = id;
                    console.log(self.loadMention);
                    var url = 'api/index.php/';
                    var data = JSON.stringify(self.loadMention);
                    $http.post(url, data).then(function(result){
                        console.log(result.data);
                        $scope.taskMention = result.data.user;
                            console.log($scope.taskMention);
                    });
                }
                
            }

            $scope.assignee_config = {
                plugins: {
                    'remove_button': {
                        label     : ''
                    }
                },
                maxItems: 1,
                valueField: 'value',
                labelField: 'name',
                searchField: 'name',
                create: false,
                placeholder: "Select Employee...",
                optgroups:taskAssignees2,
                render: {
                    optgroup_header: function(data, escape) {
                        return '<div class="optgroup-header">' + escape(data.label) + '</div>';
                    }
                }
            };

            $scope.forms_advanced = {
                "input_error": "Something wrong",
                "input_ok": "All ok",
                "ionslider_1": 23,
                "ionslider_2": {
                    "from": 160,
                    "to": 592
                },
                "ionslider_3": 40,
                "ionslider_4": {
                    "from": 20,
                    "to": 80
                },
                selectize_planets: []
            };
			
            // model change
            $timeout(function() {
                $scope.forms_advanced.datepicker = "23.06.2016"
            }, 5000);

            $scope.role = [
                {id: 1, name: 'Departmental Managers/Supervisor', value: 'senior'},
                {id: 2, name: 'Departmental Member/Junior', value: 'junior'},
            ];

            $scope.selectize_single_options = [
                {id: 1, name: 'Alaska', value: 'ak'},
                {id: 2, name: 'Hawaii', value: 'hi'},
                {id: 3, name: 'California', value: 'ca'},
                {id: 4, name: 'Nevada', value: 'nv'},
                {id: 5, name: 'Oregon', value: 'or'},
                {id: 6, name: 'Arizona', value: 'az'},
                {id: 7, name: 'Colorado', value: 'co'},
                {id: 8, name: 'Idaho', value: 'id'},
                {id: 9, name: 'Montana', value: 'mt'},
            ];
			
			$scope.selectize_usergroups_options = [
                {id: 1, name: 'Alaska', value: 'ak', optgroup: 'atz'},
                {id: 2, name: 'Hawaii', value: 'hi', optgroup: 'atz'},
                {id: 3, name: 'California', value: 'ca', optgroup: 'ptz'},
                {id: 4, name: 'Nevada', value: 'nv', optgroup: 'ptz'},
                {id: 5, name: 'Oregon', value: 'or', optgroup: 'ptz'},
                {id: 6, name: 'Arizona', value: 'az', optgroup: 'mtz'},
                {id: 7, name: 'Colorado', value: 'co', optgroup: 'mtz'},
                {id: 8, name: 'Idaho', value: 'id', optgroup: 'mtz'},
                {id: 9, name: 'Montana', value: 'mt', optgroup: 'mtz'},
            ];
			

            $scope.selectize_usergroup_department = {
                plugins: {
                    'remove_button': {
                        label     : ''
                    }
                },
                maxItems: 1,
                valueField: 'depart_id',
                labelField: 'departmentName',
                searchField: 'departmentName',
                create: false,
                placeholder: "Select Department...",
                
                render: {
                    optgroup_header: function(data, escape) {
                        return '<div class="optgroup-header">' + escape(data.label) + '</div>';
                    }
                }
            };

            $scope.selectize_user_usergroup = {
                plugins: {
                    'remove_button': {
                        label     : ''
                    }
                },
                maxItems: 1,
                valueField: 'userGroup_id',
                labelField: 'groupName',
                searchField: 'groupName',
                create: false,
                placeholder: "Select User-Group...",
                
                render: {
                    optgroup_header: function(data, escape) {
                        return '<div class="optgroup-header">' + escape(data.label) + '</div>';
                    }
                }
            };

            $scope.selectize_user_userRole = {
                plugins: {
                    'remove_button': {
                        label     : ''
                    }
                },
                maxItems: 1,
                valueField: 'id',
                labelField: 'name',
                searchField: 'name',
                create: false,
                placeholder: "Select Role...",
                
                render: {
                    optgroup_header: function(data, escape) {
                        return '<div class="optgroup-header">' + escape(data.label) + '</div>';
                    }
                }
            };


            $scope.selectize_single_config = {
                plugins: {
                    'remove_button': {
                        label     : ''
                    }
                },
                maxItems: 1,
                valueField: 'value',
                labelField: 'name',
                searchField: 'name',
                create: false,
                placeholder: "Select User Group...",
                
                render: {
                    optgroup_header: function(data, escape) {
                        return '<div class="optgroup-header">' + escape(data.label) + '</div>';
                    }
                }
            };

            $scope.selectize_planets_options = [
                {id: 1, title: 'Mercury' },
                {id: 2, title: 'Venus' },
                {id: 3, title: 'Earth' },
                {id: 4, title: 'Mars' },
                {id: 5, title: 'Jupiter'}
            ];

            $scope.selectize_planets_config = {
                plugins: {
                    'remove_button': {
                        label     : ''
                    },
                    'drag_drop': []
                },
                maxItems: null,
                valueField: 'id',
                labelField: 'title',
                searchField: 'title',
                create: false,
                render: {
                    option: function(planets_data, escape) {
                        // return  '<div class="option">' +
                            // '<span class="title">' + escape(planets_data.title) + '</span>' +
                            // '</div>';
							 return  '<div class="option">' +
                            '<span class="title">' + escape(planets_data.title) + '</span>' +
                            '</div>';
                    }
                }
            };
			
            var emails_data = $scope.selectize_emails_options = [
                {id: 1, email: 'brian@thirdroute.com', name: 'Brian Reavis'},
                {id: 2, email: 'nikola@tesla.com', name: 'Nikola Tesla'},
                {id: 3, email: 'someone@gmail.com'}
            ];

            var REGEX_EMAIL = '([a-z0-9!#$%&\'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&\'*+/=?^_`{|}~-]+)*@' +
                '(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)';

            $scope.selectize_emails_config = {
                plugins: {
                    'remove_button': {
                        label: ''
                    },
                    'drag_drop': []
                },
                persist: false,
                maxItems: null,
                valueField: 'email',
                labelField: 'name',
                searchField: ['name', 'email'],
                placeholder: "Select email",
                render: {
                    item: function(emails_data, escape) {
                        return '<div>' +
                            (emails_data.name ? '<span class="name">' + escape(emails_data.name) + '</span>' : '') +
                            (emails_data.email ? '<span class="email">' + escape(emails_data.email) + '</span>' : '') +
                            '</div>';
                    },
                    option: function(emails_data, escape) {
                        var label = emails_data.name || emails_data.email;
                        var caption = emails_data.name ? emails_data.email : null;
                        return '<div>' +
                            '<span class="label">' + escape(label) + '</span>' +
                            (caption ? '<span class="caption">' + escape(caption) + '</span>' : '') +
                            '</div>';
                    }
                },
                createFilter: function(input) {
                    var match, regex;

                    // email@address.com
                    regex = new RegExp('^' + REGEX_EMAIL + '$', 'i');
                    match = input.match(regex);
                    if (match) return !this.options.hasOwnProperty(match[0]);

                    // name <email@address.com>
                    regex = new RegExp('^([^<]*)\<' + REGEX_EMAIL + '\>$', 'i');
                    match = input.match(regex);
                    if (match) return !this.options.hasOwnProperty(match[2]);

                    return false;
                },
                create: function(input) {
                    if ((new RegExp('^' + REGEX_EMAIL + '$', 'i')).test(input)) {
                        return {email: input};
                    }
                    var match = input.match(new RegExp('^([^<]*)\<' + REGEX_EMAIL + '\>$', 'i'));
                    if (match) {
                        return {
                            email : match[2],
                            name  : $.trim(match[1])
                        };
                    }
                    alert('Invalid email address.');
                    return false;
                }
            };

        // date range
            var $dp_start = $('#uk_dp_start'),
                $dp_end = $('#uk_dp_end');

            var start_date = UIkit.datepicker($dp_start, {
                format:'DD.MM.YYYY'
            });

            var end_date = UIkit.datepicker($dp_end, {
                format:'DD.MM.YYYY'
            });

            $dp_start.on('change',function() {
                end_date.options.minDate = $dp_start.val();
            });

            $dp_end.on('change',function() {
                start_date.options.maxDate = $dp_end.val();
            });

        // masked inputs
            var $maskedInput = $('.masked_input');
            if($maskedInput.length) {
                $maskedInput.inputmask();
            }

        // ui-select
            $scope.people = [
                { name: 'Adam',      email: 'adam@email.com',      age: 12, country: 'United States' },
                { name: 'Amalie',    email: 'amalie@email.com',    age: 12, country: 'Argentina' },
                { name: 'EstefanÃ­a', email: 'estefania@email.com', age: 21, country: 'Argentina' },
                { name: 'Adrian',    email: 'adrian@email.com',    age: 21, country: 'Ecuador' },
                { name: 'Wladimir',  email: 'wladimir@email.com',  age: 30, country: 'Ecuador' },
                { name: 'Samantha',  email: 'samantha@email.com',  age: 30, country: 'United States' },
                { name: 'Nicole',    email: 'nicole@email.com',    age: 43, country: 'Colombia' },
                { name: 'Natasha',   email: 'natasha@email.com',   age: 54, country: 'Ecuador' },
                { name: 'Michael',   email: 'michael@email.com',   age: 15, country: 'Colombia' },
                { name: 'NicolÃ¡s',   email: 'nicolas@email.com',    age: 43, country: 'Colombia' }
            ];

            $scope.multipleDemo = {};
            $scope.multipleDemo.selectedPeople = [$scope.people[5], $scope.people[4]];

        }
    ]);