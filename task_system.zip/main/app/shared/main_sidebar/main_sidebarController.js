angular
    .module('altairApp')
    .controller('main_sidebarCtrl', [
        '$timeout',
        '$scope',
        '$rootScope',
        function ($timeout,$scope,$rootScope) {
    
            $scope.$on('onLastRepeat', function (scope, element, attrs) {
                $timeout(function() {
                    if(!$rootScope.miniSidebarActive) {
                        // activate current section
                        $('#sidebar_main').find('.current_section > a').trigger('click');
                    } else {
                        // add tooltips to mini sidebar
                        var tooltip_elem = $('#sidebar_main').find('.menu_tooltip');
                        tooltip_elem.each(function() {
                            var $this = $(this);
    
                            $this.attr('title',$this.find('.menu_title').text());
                            UIkit.tooltip($this, {
                                pos: 'right'
                            });
                        });
                    }
                })
            });
    
            // language switcher
            $scope.langSwitcherModel = 'gb';
            var langData = $scope.langSwitcherOptions = [
                {id: 1, title: 'English', value: 'gb'}
            ];
            $scope.langSwitcherConfig = {
                maxItems: 1,
                render: {
                    option: function(langData, escape) {
                        return  '<div class="option">' +
                            '<i class="item-icon flag-' + escape(langData.value).toUpperCase() + '"></i>' +
                            '<span>' + escape(langData.title) + '</span>' +
                            '</div>';
                    },
                    item: function(langData, escape) {
                        return '<div class="item"><i class="item-icon flag-' + escape(langData.value).toUpperCase() + '"></i></div>';
                    }
                },
                valueField: 'value',
                labelField: 'title',
                searchField: 'title',
                create: false,
                onInitialize: function(selectize) {
                    $('#lang_switcher').next().children('.selectize-input').find('input').attr('readonly',true);
                }
            };

            $scope.section_user = [
                {
                    id: 0,
                    title: 'Dashboard',
                    icon: '&#xE871;',
                    link: 'restricted.dashboard'
                },
                {
                    id: 1,
                    title: 'Tasks',
                    icon: '&#xE8D2;',
					submenu: [
						{
                            title: 'All Tasks',
                            link: 'restricted.pages.all_tasks'
                        },
                        {
                            title: 'Task List',
                            link: 'restricted.pages.tasks.list'
                        },
                        {
                            title: 'Add New',
                            link: 'restricted.pages.add_task'
                        },
						{
                            title: 'Task Reminders',
                            link: '#'
                        }
                    ]
                    
                },
                
                {
                    id: 3,
                    title: 'Reports',
                    icon: '&#xE85C;',
                    link: '#'
                },
                
               
            ]

            $scope.section_user_admin = [
                {
                    id: 0,
                    title: 'Dashboard',
                    icon: '&#xE871;',
                    link: 'restricted.dashboard'
                },
                {
                    id: 1,
                    title: 'Tasks',
                    icon: '&#xE8D2;',
					submenu: [
						{
                            title: 'All Tasks',
                            link: 'restricted.pages.all_tasks'
                        },
                        {
                            title: 'Task List',
                            link: 'restricted.pages.tasks.list'
                        },
                        {
                            title: 'Add New',
                            link: 'restricted.pages.add_task'
                        },
						{
                            title: 'Task Reminders',
                            link: '#'
                        }
                    ]
                    
                },
                {
                    id: 2,
                    title: 'Departments',
                    icon: '&#xE8C0;',
                    submenu: [
                        {
                            title: 'Add New',
                            link: 'restricted.pages.add_department'
                        },
                        {
                            title: 'View Departments',
                            link: '#'
                        },
						{
                            title: 'User Groups',
                            link: 'restricted.pages.add_usergroup'
                        }
                    ]
                },
                {
                    id: 3,
                    title: 'Reports',
                    icon: '&#xE85C;',
                    link: '#'
                },
                
                {
                    id: 3,
                    title: 'Users',
                    icon: '&#xE87C;',
					submenu: [
						{
                            title: 'Add User',
                            link: 'restricted.pages.add_user'
                        },
                        {
                            title: 'View Users',
                            link: '#'
                        }
                    ]
                }
            ]
    
            // menu entries
            if(role == '1'){
                $scope.sections = $scope.section_user_admin;
            }else{
                $scope.sections = $scope.section_user;
            }
            
    
        }
    ])
;