
var loadNewTasksAlert = [];
var loadTaskList = {};
loadTaskList.operation = "load_tasksList_list_new";
loadTaskList.user = {};
loadTaskList.user.operation = "A";
loadTaskList.user.userID = loggedinguy;
console.log(loadTaskList);
$.ajax({
    url: "api/index.php/",
    data: JSON.stringify(loadTaskList),
    type: 'POST',
    datatype: 'JSON',
    contentType: "application/json; charset=utf-8",
    success: function (result) {
        console.log(result.user);
        if(result.user === undefined){
            loadNewTasksAlert = [];
        }else{
            loadNewTasksAlert = result.user;
            console.log(loadNewTasksAlert);
        }
    }
});


console.log(role);
console.log("Logged user  Role is: " + role);
function userLogout(){
	console.log("initiate User logout for Session " + loggedinguy);
	window.location.href= 'api/logout.php';
}

angular
    .module('altairApp')
    .controller('main_headerCtrl', [
        '$timeout',
        '$scope',
        '$window',
        '$state',
        '$http',
        function ($timeout,$scope,$window,$state, $http) {
			
			var self = this;
			var getUserNamedd = "";
		        self.getUserName = "";
				self.user = {};
				self.user.operation = "get_stats";
				self.user.user = {};
				self.user.user.userID = loggedinguy;
				console.log(self.user);
				var url = 'api/index.php/';
				var data = JSON.stringify(self.user);
				$http.post(url, data).then(function(result){
					console.log(result);
					getUserNamedd = result.data.user.fname;
					console.log(getUserNamedd);
					$scope.user_data = {usename: getUserNamedd};
                });
                
                var loadTaskList = {};
                loadTaskList.operation = "load_tasksList_list_new";
                loadTaskList.user = {};
                loadTaskList.user.operation = "A";
                loadTaskList.user.userID = loggedinguy;
                console.log(loadTaskList);
                var urls = 'api/index.php/';
                var datas = JSON.stringify(loadTaskList);
                $http({ method: 'POST', url: urls, data: datas })
                    .then(function (result) {
                        console.log(result);
                        if(result.data.user === undefined){
                            $scope.task_list_dash = [];
                        }else{
                            $scope.task_list_dash = result.data.user;
                            $scope.taskLength = $scope.task_list_dash.length;
                            //return result.data.user;
                            console.log($scope.task_list_dash);
                        }
                        
                    });
				
				
			console.log(getUserNamedd);
            $scope.user_data = {
                
				//usename: "Welcome - " + getUserNamedd,
                name: "Lue Feest",
                avatar: "assets/img/avatars/user.jpg",
                alerts: [
                    {
                        "title": "News",
                        "content": "Nemo nemo voluptatem officia voluptatum minus.",
                        "type": "warning"
                    },
                    {
                        "title": "Voluptatibus sed eveniet.",
                        "content": "Tempora magnam aut ea.",
                        "type": "success"
                    },
                    {
                        "title": "Perferendis voluptatem explicabo.",
                        "content": "Enim et voluptatem maiores ab fugiat commodi aut repellendus.",
                        "type": "danger"
                    },
                    {
                        "title": "Quod minima ipsa.",
                        "content": "Vel dignissimos neque enim ad praesentium optio.",
                        "type": "primary"
                    }
                ],
                messages: [
                    {
                        "title": "Reiciendis aut rerum.",
                        "content": "In adipisci amet nostrum natus recusandae animi fugit consequatur.",
                        "sender": "Korbin Doyle",
                        "color": "cyan"
                    },
                    {
                        "title": "Tenetur commodi animi.",
                        "content": "Voluptate aut quis rerum laborum expedita qui eaque doloremque a corporis.",
                        "sender": "Alia Walter",
                        "color": "indigo",
                        "avatar": "assets/img/avatars/avatar_07_tn.png"
                    },
                    {
                        "title": "At quia quis.",
                        "content": "Fugiat rerum aperiam et deleniti fugiat corporis incidunt aut enim et distinctio.",
                        "sender": "William Block",
                        "color": "light-green"
                    },
                    {
                        "title": "Incidunt sunt.",
                        "content": "Accusamus necessitatibus officia porro nisi consectetur dolorem.",
                        "sender": "Delilah Littel",
                        "color": "blue",
                        "avatar": "assets/img/avatars/avatar_02_tn.png"
                    },
                    {
                        "title": "Porro ut.",
                        "content": "Est vitae magni eum expedita odit quisquam natus vel maiores.",
                        "sender": "Amira Hagenes",
                        "color": "amber",
                        "avatar": "assets/img/avatars/avatar_09_tn.png"
                    }
                ]
            };

            $scope.alerts_length = $scope.user_data.alerts.length;
            $scope.messages_length = loadNewTasksAlert.length;
            console.log($scope.messages_length);

            $('#menu_top').children('[data-uk-dropdown]').on('show.uk.dropdown', function(){
                $timeout(function() {
                    $($window).resize();
                },280)
            });

            // autocomplete
            $('.header_main_search_form').on('click','#autocomplete_results .item', function(e) {
                e.preventDefault();
                var $this = $(this);
                $state.go($this.attr('href'));
                $('.header_main_search_input').val('');
            })

        }
    ])
;

