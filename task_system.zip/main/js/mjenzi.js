var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : 'dashboard.html',
		controller : 'dashboardCtrl'
    })
    .when("/mail", {
        templateUrl : 'mail.htm',
        controller : 'mailCtrl'
    })
    .when("/paris", {
        templateUrl : "paris.htm",
        controller : "parisCtrl"
    })
	.when("/dashboard", {
		templateUrl : 'dashboard.html',
		controller : 'dashboardCtrl'
	});
});
app.controller('mailCtrl', function ($scope) {
    $scope.msg = "I love London";
});
app.controller("parisCtrl", function ($scope) {
    $scope.msg = "I love Paris";
});
app.controller('dashboardCtrl', function ($scope) {
    $scope.msg = 'I love Paris';
});

