<?php
session_start();
 $uri = $_SERVER["REQUEST_URI"];
$uriArray = explode('/', $uri);
$page_url3 = $uriArray[3];
$str = $page_url3;
$strs = ltrim($page_url3, '?');

echo 'Login Please Wait ...';

$_SESSION['id'] = $strs;

if(!empty($strs)){
	echo '<script type="text/javascript">
    window.location.href = "../main/";
</script>';
}


?>